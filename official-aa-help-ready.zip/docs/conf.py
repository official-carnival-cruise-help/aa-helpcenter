project = 'Official AA Help'
copyright = '2025'
author = 'Support Team'

extensions = []
templates_path = ['_templates']
exclude_patterns = []

html_theme = 'alabaster'
html_static_path = ['_static']
